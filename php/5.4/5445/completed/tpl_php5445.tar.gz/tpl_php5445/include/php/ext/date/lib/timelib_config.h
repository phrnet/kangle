#ifdef PHP_WIN32
# include "config.w32.h"
#else
# include <php_config.h>
#endif
